None (no processing)
====================

- Filter name: ``none``

This is the most simple filter. It returns the text as is.